#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <cstring>
#include <winsock2.h>
#include <ws2tcpip.h>

#pragma comment(lib, "Ws2_32.lib")

#define PORT 55555
#define KEY 3

using namespace std;

string decryptWord(const string& str)
{
    string normalStr = "";
    size_t len = str.length();
    normalStr.resize(len);

    for (size_t i = 0; i < len; i++) {
        int k = str[i] + KEY;
        if (isupper(str[i])) {
            if (k > 'Z') {

                k = 'A' + (k - 'Z' - 1);
            }
        }
        else {
            if (k > 'z') {

                k = 'a' + (k - 'z' - 1);
            }
        }

        normalStr[i] = (char)k;
    }
    return normalStr;
}

string encryptWord(const string& str)
{
    string normalStr = "";
    size_t len = str.length();
    normalStr.resize(len);

    for (size_t i = 0; i < len; i++) {
        int k = str[i] - KEY;
        if (isupper(str[i])) {
            if (k < 'A') {

                k = 'Z' - ('A' - k - 1);
            }
        }
        else {
            if (k < 'a') {

                k = 'z' - ('a' - k - 1);
            }
        }

        normalStr[i] = (char)k;
    }
    return normalStr;
}

vector<string> splitStringBySpaces(const string& str) {
    vector<string> words;
    size_t start = 0;
    size_t end = str.find(' ');

    while (end != string::npos) { //while the remaining string has more than one word
        words.push_back(str.substr(start, end - start)); 
        start = end + 1; 
        end = str.find(' ', start); // Find the next space
    }
    words.push_back(str.substr(start)); // Add the last word

    return words;
}

string CeserEncrypt(const string& str) {
    string encrypted = "";
    vector<string> words = splitStringBySpaces(str);
    size_t count = words.size();
    for (int i = 0; i < count; i++) {
        encrypted.append(encryptWord(words[i]));
        encrypted.append(" ");
    }
    encrypted.pop_back(); //delete the last space
    return encrypted;
}

string CeserDecrypt(const string& str) {
    string decrypted = "";
    vector<string> words = splitStringBySpaces(str);
    size_t count = words.size();
    for (int i = 0; i < count; i++) {
        decrypted.append(decryptWord(words[i]));
        decrypted.append(" ");
    }
    decrypted.pop_back(); //delete the last space
    return decrypted;
}



int main() {

    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "WSAStartup failed." << endl;
        return 1;
    }

    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    char buffer[1024] = { 0 };

    // Creating socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
        cerr << "Socket creation failed" << endl;
        WSACleanup();
        return 1;
    }

    // Forcefully attaching socket to the port
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, (char*)&opt, sizeof(opt)) == SOCKET_ERROR) {
        cerr << "Setsockopt failed" << endl;
        closesocket(server_fd);
        WSACleanup();
        return 1;
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // Binding the socket
    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) == SOCKET_ERROR) {
        cerr << "Bind failed" << endl;
        closesocket(server_fd);
        WSACleanup();
        return 1;
    }

    if (listen(server_fd, 3) == SOCKET_ERROR) {
        cerr << "Listen failed" << endl;
        closesocket(server_fd);
        WSACleanup();
        return 1;
    }

    cout << "Server is listening on port " << PORT << "..." << endl;

    if ((new_socket = accept(server_fd, (struct sockaddr*)&address, (int*)&addrlen)) == INVALID_SOCKET) {
        cerr << "Accept failed" << endl;
        closesocket(server_fd);
        WSACleanup();
        return 1;
    }

    cout << "Connection established with client." << endl;

    while (true) {
        memset(buffer, 0, sizeof(buffer));
        int valread = recv(new_socket, buffer, 1024, 0);
        if (valread <= 0) {
            cout << "Client disconnected." << endl;
            break;
        }

        string text(buffer);
        cout << "Received: " << text << endl;

        vector<string> rcv = splitStringBySpaces(text);
        
        size_t pos = text.find(' ');
        string firstWord = text.substr(0, pos);
        text = text.substr(pos + 1);

        if (firstWord == "encr") {
            text = CeserEncrypt(text);
            send(new_socket, text.c_str(), text.size(), 0);
        }
        else if(firstWord == "decr") {
            text = CeserDecrypt(text);
            send(new_socket, text.c_str(), text.size(), 0);
        }
        else {
            text = "Operation not specified!";
            send(new_socket, text.c_str(), text.size(), 0);
        }

      
        cout << "Sent: " << text << endl;
    }

    closesocket(new_socket);
    closesocket(server_fd);
    WSACleanup();
    return 0;
}